import { testSuite } from '../../support/testSuite'

testSuite.tests.miscellaneous.isMonoSpace()
