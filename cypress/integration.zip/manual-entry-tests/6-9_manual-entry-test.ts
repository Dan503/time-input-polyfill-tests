import { testSuite } from '../../support/testSuite'

testSuite.tests.manualEntry._6_9()
