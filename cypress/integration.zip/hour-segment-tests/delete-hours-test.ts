import { testSuite } from '../../support/testSuite'

testSuite.tests.hours.delete()
