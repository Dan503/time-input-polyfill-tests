import { testSuite } from '../../support/testSuite'

// Note: you may need to change the hasSynchronizedEvents setting
testSuite.tests.events.inputEvents({ hasSynchronizedEvents: false })
