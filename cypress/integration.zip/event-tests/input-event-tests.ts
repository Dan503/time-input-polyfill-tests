import { testSuite } from '../../support/testSuite'

testSuite.tests.events.inputEvents()
